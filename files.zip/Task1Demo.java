// Task1Demo.java
// Task 1 - Build a class and prove independent object state
// Roshan Ahmed | SP26-BAI-043

public class Task1Demo {
    public static void main(String[] args) {
        // Three independent Student objects
        Student s1 = new Student();
        Student s2 = new Student();
        Student s3 = new Student();

        s1.studentId = "SP26-BAI-001";
        s1.name = "Abeer Amina";
        s1.completedCredits = 45;

        s2.studentId = "SP26-BAI-002";
        s2.name = "Ali Ishtiaq";
        s2.completedCredits = 60;

        s3.studentId = "SP26-BAI-043";
        s3.name = "Roshan Ahmed";
        s3.completedCredits = 30;

        System.out.println("--- Before change ---");
        printStudent(s1);
        printStudent(s2);
        printStudent(s3);

        // Modify only s2
        s2.completedCredits += 6;

        System.out.println("\n--- After changing only s2 ---");
        printStudent(s1);
        printStudent(s2);
        printStudent(s3);

        // Explanation:
        // s1, s2, and s3 each hold a reference to a SEPARATE Student object on the heap,
        // so each object has its own copy of the instance variables.
        // Changing s2.completedCredits only touches the object s2 points to,
        // leaving s1 and s3 untouched.
    }

    static void printStudent(Student s) {
        System.out.println(s.studentId + " | " + s.name
                + " | completedCredits=" + s.completedCredits);
    }
}
