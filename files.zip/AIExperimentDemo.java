// AIExperimentDemo.java
// Task 5 - Integrated BAI challenge: AIExperiment demo
// Roshan Ahmed | SP26-BAI-043

public class AIExperimentDemo {

    // R9: helper method that mutates completedEpochs through a copied reference
    static void trainMore(AIExperiment exp, int epochs) {
        exp.completedEpochs += epochs;
    }

    public static void main(String[] args) {
        // R2: two independent AIExperiment objects
        AIExperiment expA = new AIExperiment();
        expA.experimentName = "ImageClassifier-CNN";
        expA.completedEpochs = 5;
        expA.targetEpochs = 20;

        AIExperiment expB = new AIExperiment();
        expB.experimentName = "SentimentLSTM";
        expB.completedEpochs = 8;
        expB.targetEpochs = 15;

        System.out.println("--- Initial state ---");
        System.out.println(expA.status());
        System.out.println(expB.status());

        // R3: single-arg runEpochs
        expA.runEpochs(3);
        // R4: two-arg overload
        expB.runEpochs(2, 1);

        System.out.println("\n--- After runEpochs calls ---");
        System.out.println(expA.status());
        System.out.println(expB.status());

        // R5: remaining epochs
        System.out.println("\nexpA remaining epochs: " + expA.remainingEpochs());
        System.out.println("expB remaining epochs: " + expB.remainingEpochs());

        // R8: changing one experiment does not change the other
        System.out.println("\n--- Proving independence: modify only expA ---");
        expA.runEpochs(4);
        System.out.println(expA.status() + "   <- changed");
        System.out.println(expB.status() + "   <- unchanged, separate object");

        // R9: pass-by-value mutation experiment
        System.out.println("\n--- Helper method mutation (trainMore) ---");
        System.out.println("Before: " + expA.status());
        trainMore(expA, 5);
        System.out.println("After:  " + expA.status());
        // Explanation: exp inside trainMore is a copy of the reference stored in expA,
        // but that copy still points to the SAME AIExperiment object on the heap.
        // So exp.completedEpochs += epochs mutates the real object, and the change
        // is visible to the caller once the method returns.
    }
}
