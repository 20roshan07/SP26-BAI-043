// Task2Demo.java
// Task 2 - Methods, parameters, local variables, return values
// Roshan Ahmed | SP26-BAI-043

public class Task2Demo {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.studentId = "SP26-BAI-043";
        s1.name = "Roshan Ahmed";
        s1.completedCredits = 90;

        Student s2 = new Student();
        s2.studentId = "SP26-BAI-002";
        s2.name = "Ali Ishtiaq";
        s2.completedCredits = 60;

        // Prediction: s1.completedCredits 90 -> 96 after addCredits(6)
        s1.addCredits(6);
        System.out.println(s1.summary());
        // Prediction: remaining = 130 - 96 = 34
        System.out.println("Remaining for s1: " + s1.remainingCredits(130));

        // Prediction: s2.completedCredits 60 -> 72 after addCredits(12)
        s2.addCredits(12);
        System.out.println(s2.summary());
        // Prediction: remaining = 120 - 72 = 48
        System.out.println("Remaining for s2: " + s2.remainingCredits(120));

        // credits (in addCredits) is a PARAMETER: a copy of the value passed at the
        // call site. completedCredits is a FIELD: it persists on the object between
        // calls. remaining (in remainingCredits) is a LOCAL VARIABLE: it exists only
        // for that method call, so it's better local than a field.
    }
}
