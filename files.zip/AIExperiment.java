// AIExperiment.java
// Task 5 - Integrated BAI challenge
// Roshan Ahmed | SP26-BAI-043

class AIExperiment {
    // Instance variables (persistent state per experiment)
    String experimentName;
    int completedEpochs;
    int targetEpochs;

    // R3: increase completedEpochs
    void runEpochs(int epochs) {
        completedEpochs += epochs;
    }

    // R4: overload - run epochs plus a bonus amount
    void runEpochs(int epochs, int bonusEpochs) {
        completedEpochs += epochs + bonusEpochs;
    }

    // R5 + R7: local variable used for the computation
    int remainingEpochs() {
        int remaining = targetEpochs - completedEpochs;
        return remaining;
    }

    // R6: readable one-line summary
    String status() {
        return experimentName + ": " + completedEpochs + "/" + targetEpochs +
               " epochs complete (" + remainingEpochs() + " remaining)";
    }
}
