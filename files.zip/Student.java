// Student.java
// CSC241 - Object Oriented Programming - Lab 02
// Roshan Ahmed | SP26-BAI-043

class Student {
    // Instance variables (persistent per-object state)
    String studentId;
    String name;
    int completedCredits;

    // ---- Task 2: instance methods ----

    // Modifies state: adds credits to this object's field
    void addCredits(int credits) {
        completedCredits += credits;
    }

    // Uses a local variable, returns a computed value
    int remainingCredits(int degreeCredits) {
        int remaining = degreeCredits - completedCredits;
        return remaining;
    }

    // Returns a readable one-line summary
    String summary() {
        return studentId + " - " + name + " (" + completedCredits + " credits completed)";
    }
}
