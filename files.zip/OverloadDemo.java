// OverloadDemo.java
// Task 3 - Method signatures and overloading
// Roshan Ahmed | SP26-BAI-043

public class OverloadDemo {

    // Signature: enroll(String)
    void enroll(String courseCode) {
        System.out.println("Enrolled in " + courseCode);
    }

    // Signature: enroll(String, int)
    void enroll(String courseCode, int section) {
        System.out.println("Enrolled in " + courseCode + ", section " + section);
    }

    // Signature: enroll(int)
    void enroll(int numericCourseCode) {
        System.out.println("Enrolled in numeric course " + numericCourseCode);
    }

    // INVALID OVERLOAD ATTEMPT (differs only by return type) - kept commented,
    // see compiler_notes.txt for the exact javac error this produced:
    // int enroll(String courseCode) { return 0; }
    // javac error: "method enroll(String) is already defined in class OverloadDemo"

    public static void main(String[] args) {
        OverloadDemo demo = new OverloadDemo();

        // Predictions before compiling:
        // enroll("CSC241")        -> "Enrolled in CSC241"
        // enroll("CSC241", 2)     -> "Enrolled in CSC241, section 2"
        // enroll(241)             -> "Enrolled in numeric course 241"
        demo.enroll("CSC241");
        demo.enroll("CSC241", 2);
        demo.enroll(241);

        // Invalid calls (left as comments - would not compile):
        // demo.enroll();                 // no matching signature enroll()
        // demo.enroll("241", "2");       // no enroll(String, String) overload exists
    }
}
