// PassByValueDemo.java
// Task 4 - Prove Java pass-by-value
// Roshan Ahmed | SP26-BAI-043

public class PassByValueDemo {

    // Experiment A: primitive int
    static void changeNumber(int x) {
        System.out.println("  Inside changeNumber, before: x = " + x);
        x = 99;
        System.out.println("  Inside changeNumber, after:  x = " + x);
    }

    // Experiment B: object reference, mutate the object it points to
    static void changeStudent(Student st) {
        System.out.println("  Inside changeStudent, before: credits = " + st.completedCredits);
        st.completedCredits = 99;
        System.out.println("  Inside changeStudent, after:  credits = " + st.completedCredits);
    }

    // Experiment C: object reference, reassign the LOCAL parameter to a new object
    static void replaceStudent(Student st) {
        System.out.println("  Inside replaceStudent, before: name = " + st.name);
        st = new Student();
        st.name = "Temporary";
        System.out.println("  Inside replaceStudent, after:  new Student name=" + st.name);
    }

    public static void main(String[] args) {
        System.out.println("=== Experiment A: primitive int ===");
        int number = 10;
        System.out.println("Before call: number = " + number);
        changeNumber(number);
        System.out.println("After call:  number = " + number);
        // The argument value is copied into the parameter, so x is an independent
        // copy of number; reassigning x has no effect on the caller's variable.

        System.out.println("\n=== Experiment B: object reference, mutate the object ===");
        Student st = new Student();
        st.studentId = "SP26-BAI-043";
        st.name = "Roshan Ahmed";
        st.completedCredits = 30;
        System.out.println("Before call: completedCredits = " + st.completedCredits);
        changeStudent(st);
        System.out.println("After call:  completedCredits = " + st.completedCredits);
        // The argument value is copied into the parameter, but for an object argument that
        // value is a reference (a pointer to the same object on the heap). st and the
        // parameter refer to the SAME Student object, so mutating a field through the
        // parameter is visible to the caller.

        System.out.println("\n=== Experiment C: object reference, reassign the parameter ===");
        Student st2 = new Student();
        st2.studentId = "SP26-BAI-002";
        st2.name = "Ali Ishtiaq";
        System.out.println("Before call: name = " + st2.name);
        replaceStudent(st2);
        System.out.println("After call:  name = " + st2.name);
        // The argument value is copied into the parameter, so replacing st with
        // "st = new Student()" only redirects the LOCAL copy of the reference inside the
        // method. The caller's st2 variable still points to the original object, unchanged.

        System.out.println("\nRequired: changeStudent(...) affects the object because the");
        System.out.println("copied reference points to the same heap object, so mutations go");
        System.out.println("through it. replaceStudent(...) can't redirect the caller's");
        System.out.println("variable: only the parameter's copy of the reference changes.");
    }
}
